<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('/loginattempt', 'APIControllers\UsersLoginController@loginAttempt');

Route::get('/user', 'APIControllers\UsersController@index');
Route::post('/user/{id}', 'APIControllers\UsersController@indexgetid');
Route::get('/department', 'APIControllers\DepartmentController@index');
Route::post('/department/{id}', 'APIControllers\DepartmentController@indexgetid');
