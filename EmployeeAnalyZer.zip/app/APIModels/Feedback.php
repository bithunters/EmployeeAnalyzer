<?php

namespace App\APIModels;

use Illuminate\Database\Eloquent\Model;

class Feedback extends Model
{
    //
}
