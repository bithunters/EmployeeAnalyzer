<?php

namespace App\APIModels;

use Illuminate\Database\Eloquent\Model;

class Attendencerecord extends Model
{
	protected $primaryKey = 'EmpID';
	public $timestamps = false;
    //
}
