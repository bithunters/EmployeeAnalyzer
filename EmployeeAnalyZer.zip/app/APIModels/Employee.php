<?php

namespace App\APIModels;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    //
}
