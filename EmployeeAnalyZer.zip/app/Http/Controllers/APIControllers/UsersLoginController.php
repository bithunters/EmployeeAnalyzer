<?php

namespace App\Http\Controllers\APIControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\APIModels\User;


class UsersLoginController extends Controller
{
    public function loginAttempt(Request $request){

    	 $userid = $request->input('userid');
    	 $password = $request->input('password');
    	// if(\DB::table('users')->where('name', $userid)->first()->name == null){
    	// 	return ture;
    	// }else{
    	// 	$s = \DB::table('users')->where('name', $userid)->first();
    	// 	return false;
    	// }

    	if(\DB::table('users')->where('email', $userid)->first() != null ){
    		$password_d = \DB::table('users')->where('email', $userid)->first()->password;
    		//return $userid;
    		if($password == $password_d){
    			return 'true';
    		}else{
    			return 'false';
    		}
    		
    	} else{

    		    return 'false';
    	}
    	

    	
    }
}
